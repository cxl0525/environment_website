create
    definer = root@localhost procedure update_activity_status()
BEGIN
    IF exists (select actId from activity where SYSDATE()<actRegDate) THEN
            update activity set `actStatus`=1 where SYSDATE()<activity_time and `actStatus`!=1;
    END IF;
		IF exists (select actId from activity where SYSDATE()>=actRegDate and  SYSDATE()<=actRegDeadline) THEN
            update activity set `actStatus`=2 where SYSDATE()>=actRegDate and  SYSDATE()<=actRegDeadline and `actStatus`!=2;
    END IF;
		IF exists (select actId from activity where SYSDATE()>actRegDeadline and SYSDATE()<actStartDate) THEN
            update activity set `actStatus`=3 where SYSDATE()>actRegDeadline and SYSDATE()<actStartDate and `actStatus`!=3;
    END IF;
		IF exists (select actId from activity where SYSDATE()>=actStartDate and SYSDATE()<=actDeadLine) THEN
            update activity set `actStatus`=4 where SYSDATE()>=actStartDate and SYSDATE()<=actDeadLine and `actStatus`!=4;
    END IF;
		IF exists (select actId from activity where SYSDATE()>actDeadLine) THEN
            update activity set `actStatus`=5 where SYSDATE()>actDeadLine and `actStatus`!=5;
    END IF;
END;

