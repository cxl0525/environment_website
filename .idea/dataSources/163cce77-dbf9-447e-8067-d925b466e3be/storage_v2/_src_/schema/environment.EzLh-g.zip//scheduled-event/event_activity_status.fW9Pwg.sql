create definer = root@localhost event event_activity_status on schedule
    every '1' SECOND
        starts '2020-05-19 22:18:03'
    on completion preserve
    enable
    do
    begin
call update_activity_status();
end;

